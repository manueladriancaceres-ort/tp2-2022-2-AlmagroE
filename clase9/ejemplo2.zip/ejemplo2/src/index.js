console.log("Sistema");
import Cliente from './models/Cliente.js';
const cliente = new Cliente(25235);
console.log(cliente.getNumero());
