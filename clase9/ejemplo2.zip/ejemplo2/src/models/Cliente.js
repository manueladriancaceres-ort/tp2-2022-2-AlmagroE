class Cliente {
    constructor(numero) {
        this.numero = numero;
    }
    getNumero() {
        return this.numero;
    }
    setNumer(numero) {
        this.numero = numero;
    }
}
export default Cliente;
